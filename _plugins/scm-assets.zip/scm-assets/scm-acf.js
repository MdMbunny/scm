( function($){

// ******************************************************			
// ******************************************************
	// jQuery READY
// ******************************************************
// ******************************************************


		
	jQuery(function($){
	
		/*console.log('a');
		var $forms_sections = $( '.form-sections' );
		for (var i = 0; i < $forms_sections.length; i++) {
			console.log('p');
			var $form_section = $( $forms_sections[i] );
			var form_id = $form_section.data( 'form-id' );
			var $form_row = $( '[data-row-id="' + form_id + '"]' );
			
			if( $form_row.length ){
				$form_section.css( { 
					width: $form_row.outerWidth(),
				});
				$form_row.replaceWith( $form_section );
			}
		};*/
		
	});

} )( jQuery );

