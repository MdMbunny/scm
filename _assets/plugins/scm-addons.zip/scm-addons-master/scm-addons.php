<?php
/**
 * Plugin Name:         SCM Addons
 * Plugin URI:          http://studiocreativo-m.it/
 * Description:         SCM Addons
 * Version:             1.0.0
 * Author:              Studio Creativo M
 * Author URI:          http://studiocreativo-m.it/
 * License:             http://www.gnu.org/licenses/gpl-3.0.html
 * GitHub Plugin URI:   MdMbunny/scm-addons
 * GitHub Branch:       master
 */

/*
*****************************************************
*
*   0.0 Actions and Filters
*   1.0 Assets
*   3.0 Require
*
*****************************************************
*/

// *****************************************************
// *      0.0 ACTIONS AND FILTERS
// *****************************************************
    
    add_action( 'plugins_loaded', 'scm_addons_init' );


// *****************************************************
// *      1.0 ASSETS
// *****************************************************

    if ( ! function_exists( 'scm_addons_init' ) ) {
        function scm_addons_init() {
            
            define( 'SCM_ADDONS_DIR',                    dirname(__FILE__) . '/' );
            define( 'SCM_ADDONS_URI',                    plugin_dir_url(__FILE__) );
            define( 'SCM_ADDONS_DIR_ASSETS',             SCM_ADDONS_DIR . 'assets/' );
            define( 'SCM_ADDONS_URI_ASSETS',             SCM_ADDONS_URI . 'assets/' );
            
        }
    }


// *****************************************************
// *      2.0 REQUIRE
// *****************************************************

require_once( SCM_ADDONS_DIR_ASSETS . 'php/typekit-client.php' );
require_once( SCM_ADDONS_DIR_ASSETS . 'php/Get_Template_Part.php' );
require_once( SCM_ADDONS_DIR_ASSETS . 'php/class-tgm-plugin-activation.php' );
require_once( SCM_ADDONS_DIR_ASSETS . 'php/Backup_Restore_Options.php' );