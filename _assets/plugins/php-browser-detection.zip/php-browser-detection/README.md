php-browser-detection
=====================

PHP Browser Detection is a WordPress plugin used to detect a user's browser.

https://wordpress.org/plugins/php-browser-detection/
