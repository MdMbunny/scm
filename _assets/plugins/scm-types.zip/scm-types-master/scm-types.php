<?php
/**
 * Plugin Name:         SCM Types
 * Plugin URI:          http://studiocreativo-m.it/
 * Description:         SCM Custom Types and Taxonomies
 * Version:             1.0.0
 * Author:              Studio Creativo M
 * Author URI:          http://studiocreativo-m.it/
 * License:             http://www.gnu.org/licenses/gpl-3.0.html
 * GitHub Plugin URI:   MdMbunny/scm-types
 * GitHub Branch:       master
 */

/*
*****************************************************
*
*   0.0 Actions and Filters
*   1.0 Assets
*   2.0 Require
*
*****************************************************
*/

// *****************************************************
// *      0.0 ACTIONS AND FILTERS
// *****************************************************
    
    add_action( 'plugins_loaded', 'scm_types_init' );


// *****************************************************
// *      1.0 ASSETS
// *****************************************************

    if ( ! function_exists( 'scm_types_init' ) ) {
        function scm_types_init() {
            
            define( 'SCM_TYPES_DIR',                    dirname(__FILE__) . '/' );
            define( 'SCM_TYPES_URI',                    plugin_dir_url(__FILE__) );
            define( 'SCM_TYPES_DIR_ASSETS',             SCM_TYPES_DIR . 'assets/' );
            define( 'SCM_TYPES_URI_ASSETS',             SCM_TYPES_URI . 'assets/' );
            
        }
    }

// *****************************************************
// *      2.0 REQUIRE
// *****************************************************

require_once( SCM_TYPES_DIR_ASSETS . 'php/Custom_Type.php' );
require_once( SCM_TYPES_DIR_ASSETS . 'php/Custom_Taxonomy.php' );