<?php
/**
 * Plugin Name:         SCM Admin UI
 * Plugin URI:          http://studiocreativo-m.it/
 * Description:         SCM Admin User Interface
 * Version:             1.0.0
 * Author:              Studio Creativo M
 * Author URI:          http://studiocreativo-m.it/
 * License:             http://www.gnu.org/licenses/gpl-3.0.html
 * GitHub Plugin URI:   MdMbunny/scm-admin-ui
 * GitHub Branch:       master
 */

// *****************************************************
// *      0.0 INIT - [AUTOMATIC - DO NOT TOUCH]
// *****************************************************

    add_action( 'plugins_loaded', 'scm_plugin_init' );

    // Init Plugin
    if ( ! function_exists( 'scm_plugin_init' ) ) {
        function scm_plugin_init($file){
            //print( $file . ' FROM ' . __FILE__ );
            $file = ( $file ?: __FILE__ );
            $plugin = scm_plugin_name( $file );
            $slug = sanitize_title( $plugin );
            $name = strtoupper( str_replace( '-', '_', $slug ) );
            $dir = dirname( $file ) . '/';
            $uri = plugin_dir_url( $file );

            // PLUGIN CONSTANTS
            define( $name,                             $slug );
            define( $name . '_VERSION',                scm_plugin_version( $file ) );
            define( $name . '_DIR',                    $dir );
            define( $name . '_URI',                    $uri );
            define( $name . '_DIR_ASSETS',             $dir . 'assets/' );
            define( $name . '_URI_ASSETS',             $uri . 'assets/' );
            define( $name . '_DIR_LANG',               $dir . 'lang/' );
            define( $name . '_URI_LANG',               $uri . 'lang/' );

            // PLUGIN TEXTDOMAIN
            load_plugin_textdomain( $slug, false, $dir . 'lang/' );
        }
    }else{
        //print('ALREADY EXISTS, SO...');
        scm_plugin_init( __FILE__ );
    }

    // Get Plugin Data
    if ( ! function_exists( 'scm_plugin_data' ) ) {
        // All Data
        function scm_plugin_data( $file ) {
            if ( ! function_exists( 'get_plugins' ) )
                require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
            $plugin_folder = get_plugins( '/' . plugin_basename( dirname( $file ) ) );
            $plugin_file = basename( ( $file ) );
            return $plugin_folder[ $plugin_file ];
        }
        // Name
        function scm_plugin_name( $file ) {
            return scm_plugin_data( $file )[ 'Name' ];
        }
        // Version
        function scm_plugin_version( $file ) {
            return scm_plugin_data( $file )[ 'Version' ];
        }
    }
    

// ***************************************************************************************************************************************************************
// ***************************************************************************************************************************************************************
// *** CUSTOM CODE GOES HERE *************************************************************************************************************************************
// ***************************************************************************************************************************************************************
// ***************************************************************************************************************************************************************

/*
*****************************************************
*
*   0.0 Actions and Filters
*   1.0 Assets
*
*****************************************************
*/

// *****************************************************
// *      0.0 ACTIONS AND FILTERS
// *****************************************************

    show_admin_bar(false);

// ***      1.1 MENU
    add_action( 'admin_menu', 'scm_admin_ui_menu');
    add_filter( 'custom_menu_order', 'scm_admin_ui_menu_order' );
    add_filter( 'menu_order', 'scm_admin_ui_menu_order' );

// ***      1.2 HIDE
    add_action( 'wp_dashboard_setup', 'scm_admin_ui_hide_dashboard_widgets' );
    add_action( 'admin_head', 'scm_admin_ui_hide_from_users' );
    add_action( 'pre_user_query', 'scm_admin_ui_hide_admin_from_users' );
    add_action( 'admin_bar_menu', 'scm_admin_ui_hide_tools', 999 );


// *****************************************************
// *      1.0 ASSETS
// *****************************************************

// ***      1.1 MENU

    // Set Menu Elements Order
    if ( ! function_exists( 'scm_admin_ui_menu_order' ) ) {
        function scm_admin_ui_menu_order($menu_ord) {
            
            if ( !$menu_ord ) return true;

            $menu_order = array(
                'scm' => array(
                    'index.php', // Dashboard
                    'scm-options-intro',
                    'scm-default-types',
                    'scm-templates-general',
                ),
                'separator1' => array( 'separator1' ),
                'pages' => array(
                    'edit.php?post_type=page', // Pages
                ),
                'separator2' => array( 'separator2' ),
                'types' => array(
                    'edit.php', // Posts
                ),
                'separator3' => array( 'separator3' ),
                'media' => array(
                    'upload.php', // Media
                ),
                'separator4' => array( 'separator4' ),
                'contacts' => array(
                    'edit-comments.php', // Comments
                    'link-manager.php', // Links
                    'users.php', // Users
                    'wpcf7', // Forms
                ),
                'separator5' => array( 'separator5' ),
                'settings' => array(
                    'themes.php', // Appearance
                    'plugins.php', // Plugins
                    'tools.php', // Tools
                    'options-general.php', // Settings
                ),
                'separator-last' => array( 'separator-last' ),
            );

            $menu_order = apply_filters( 'scm_filter_admin_menu_order', $menu_order );

            return call_user_func_array( 'array_merge', $menu_order );

        }
    }

    // Set Default WP Menu Elements
    if ( ! function_exists( 'scm_admin_ui_menu' ) ) {
        function scm_admin_ui_menu(){

            remove_menu_page( 'index.php' );                                    //Dashboard
            remove_menu_page( 'edit.php' );                                     //Posts

            remove_menu_page( 'edit-comments.php' );                            //Comments
            remove_menu_page( 'link-manager.php' );                             //Links
            remove_menu_page( 'edit-tags.php?taxonomy=link_category' );         //Links

            remove_menu_page( 'edit-tags.php?taxonomy=category');               //Categories
            remove_menu_page( 'edit-tags.php?taxonomy=post_tag');               //Tags

            global $menu;
            ksort( $menu );

            $menu[] = array('','read',"separator3",'','wp-menu-separator');
            $menu[] = array('','read',"separator4",'','wp-menu-separator');
            $menu[] = array('','read',"separator5",'','wp-menu-separator');
            
        }
    }

// ***      1.2 HIDE

    // Remove Dashboard Widgets
    if ( ! function_exists( 'scm_admin_ui_hide_dashboard_widgets' ) ) {
        function scm_admin_ui_hide_dashboard_widgets(){
            remove_action( 'welcome_panel', 'wp_welcome_panel' );
            remove_meta_box('dashboard_activity', 'dashboard', 'normal');   // Activity
            remove_meta_box('dashboard_right_now', 'dashboard', 'normal');   // Right Now
            remove_meta_box('dashboard_recent_comments', 'dashboard', 'normal'); // Recent Comments
            remove_meta_box('dashboard_incoming_links', 'dashboard', 'normal');  // Incoming Links
            remove_meta_box('dashboard_plugins', 'dashboard', 'normal');   // Plugins
            remove_meta_box('dashboard_quick_press', 'dashboard', 'side');  // Quick Press
            remove_meta_box('dashboard_recent_drafts', 'dashboard', 'side');  // Recent Drafts
            remove_meta_box('dashboard_primary', 'dashboard', 'side');   // WordPress blog
            remove_meta_box('dashboard_secondary', 'dashboard', 'side');   // Other WordPress News
        }
    }

    // Removes Screen Meta Links to Users
    if ( ! function_exists( 'scm_admin_ui_hide_from_users' ) ) {
        function scm_admin_ui_hide_from_users(){

            if( $_SERVER['REQUEST_URI'] == '/wp-admin/options-media.php' ){
                echo '<style>

                    #wpbody-content .wrap form tr > td{
                        padding: 0;
                        margin: 0;
                    }

                    #wpbody-content .wrap form > h2,
                    #wpbody-content .wrap form > p,
                    #wpbody-content .wrap form tr > *:not(td),
                    #wpbody-content .wrap form tr > td > *:not(#oir-remove-image-sizes){
                        display: none;
                    }

                    #oir-remove-image-sizes, #oir-remove-image-sizes+p, #oir-remove-image-sizes+p+p{
                        display: block !important;
                    }

                </style>';

            }
           
            if( !current_user_can( 'manage_options' ) )
                echo '<style>#screen-meta-links{display: none !important;}</style>';

            if (!current_user_can('update_core')) {
                remove_action( 'admin_notices', 'update_nag', 3 );
            }            
        }
    }

    // Hides Administrator From User List
    if ( ! function_exists( 'scm_admin_ui_hide_admin_from_users' ) ) {
        function scm_admin_ui_hide_admin_from_users($user_search) {
            if(current_user_can('update_core')) {
                global $wpdb;
                $user_search->query_where = str_replace('WHERE 1=1',
                    "WHERE 1=1 AND {$wpdb->users}.ID<>1",$user_search->query_where);
            }
        }
    }

    // Hides Tools from Toolbar (Top Bar)
    if ( ! function_exists( 'scm_admin_ui_hide_tools' ) ) {
        function scm_admin_ui_hide_tools( $wp_admin_bar ) {
            $wp_admin_bar->remove_node( 'wp-logo' );
            $wp_admin_bar->remove_node( 'comments' );
            $wp_admin_bar->remove_node( 'new-post' );
            $wp_admin_bar->remove_node( 'new-media' );
            $wp_admin_bar->remove_node( 'new-page' );
            $wp_admin_bar->remove_node( 'view' );
        }
    }


