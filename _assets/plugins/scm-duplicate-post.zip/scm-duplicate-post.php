<?php
/**
 * Plugin Name:         SCM Duplicate Post
 * Plugin URI:          http://studiocreativo-m.it/
 * Description:         Duplicate Post and Pages Integration
 * Version:             1.0.1
 * Author:              Studio Creativo M
 * Author URI:          http://studiocreativo-m.it/
 * License:             http://www.gnu.org/licenses/gpl-3.0.html
 * GitHub Plugin URI:   MdMbunny/scm-duplicate-post
 * GitHub Branch:       master
 */

/*
*****************************************************
*
*   0.0 Actions and Filters
*   1.0 Init
*   2.0 Assets
*
*****************************************************
*/

// *****************************************************
// *      0.0 ACTIONS AND FILTERS
// *****************************************************

    add_action( 'plugins_loaded', 'scm_duplicate_post_init' );
    add_action( 'admin_action_scm_duplicate_post', 'scm_duplicate_post' );
    add_filter( 'page_row_actions', 'scm_duplicate_post_link', 10, 2 );
    add_filter( 'post_row_actions', 'scm_duplicate_post_link', 10, 2 );

}

// *****************************************************
// *      1.0 Assets
// *****************************************************

    if ( ! function_exists( 'scm_duplicate_post_version' ) ) {
        function scm_duplicate_post_version() {
            if ( ! function_exists( 'get_plugins' ) )
                require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
            $plugin_folder = get_plugins( '/' . plugin_basename( dirname( __FILE__ ) ) );
            $plugin_file = basename( ( __FILE__ ) );
            return $plugin_folder[$plugin_file]['Version'];
        }
    }

    if ( ! function_exists( 'scm_duplicate_post_init' ) ) {
        function scm_duplicate_post_init(){

            define( 'SCM_DUPLICATE_POST',                        'scm-duplicate-post' );
            define( 'SCM_DUPLICATE_POST_VERSION',                scm_duplicate_post_version() );
            define( 'SCM_DUPLICATE_POST_DIR',                    dirname(__FILE__) . '/' );
            define( 'SCM_DUPLICATE_POST_URI',                    plugin_dir_url(__FILE__) );
            define( 'SCM_DUPLICATE_POST_DIR_LANG',               SCM_DUPLICATE_POST_DIR . 'lang/' );
            define( 'SCM_DUPLICATE_POST_URI_LANG',               SCM_DUPLICATE_POST_URI . 'lang/' );

            load_plugin_textdomain( SCM_DUPLICATE_POST, false, SCM_DUPLICATE_POST_DIR_LANG );
        }
    }


// *****************************************************
// *      2.0 Assets
// *****************************************************

// Function creates post duplicate as a draft and redirects then to the edit post screen
    if ( ! function_exists( 'scm_duplicate_post' ) ) {
        function scm_duplicate_post(){

            global $wpdb;

            if ( !( isset( $_GET['post']) || isset( $_POST['post']) || ( isset($_REQUEST['action']) && 'scm_duplicate_post' == $_REQUEST['action'] ) ) ) {
                wp_die( __( 'No post to duplicate has been supplied!', SCM_DUPLICATE_POST ) );
            }

            $post_id = ( isset( $_GET['post'] ) ? $_GET['post'] : $_POST['post'] );
            $post = get_post( $post_id );
            $current_user = wp_get_current_user();
            $new_post_author = $current_user->ID;
         
            if (isset( $post ) && $post != null) {

                $args = array(
                    'comment_status' => $post->comment_status,
                    'ping_status'    => $post->ping_status,
                    'post_author'    => $new_post_author,
                    'post_content'   => $post->post_content,
                    'post_excerpt'   => $post->post_excerpt,
                    'post_name'      => $post->post_name,
                    'post_parent'    => $post->post_parent,
                    'post_password'  => $post->post_password,
                    'post_status'    => 'draft',
                    'post_title'     => $post->post_title,
                    'post_type'      => $post->post_type,
                    'to_ping'        => $post->to_ping,
                    'menu_order'     => $post->menu_order
                );

                $new_post_id = wp_insert_post( $args );

                $taxonomies = get_object_taxonomies( $post->post_type );
                foreach ( $taxonomies as $taxonomy ) {

                    $post_terms = wp_get_object_terms( $post_id, $taxonomy, array( 'fields' => 'slugs' ) );
                    wp_set_object_terms( $new_post_id, $post_terms, $taxonomy, false );

                }

                $post_meta_infos = $wpdb->get_results( "SELECT meta_key, meta_value FROM $wpdb->postmeta WHERE post_id=$post_id" );
                
                if (count($post_meta_infos)!=0) {

                    $sql_query = "INSERT INTO $wpdb->postmeta (post_id, meta_key, meta_value) ";

                    foreach ( $post_meta_infos as $meta_info ) {
                        $meta_key = $meta_info->meta_key;
                        $meta_value = addslashes( $meta_info->meta_value );
                        $sql_query_sel[] = "SELECT $new_post_id, '$meta_key', '$meta_value'";
                    }

                    $sql_query.= implode( " UNION ALL ", $sql_query_sel );
                    $wpdb->query( $sql_query );

                }

                wp_redirect( admin_url( 'post.php?action=edit&post=' . $new_post_id ) );

                exit;

            } else {

                wp_die( __( 'Post creation failed, could not find original post', SCM_DUPLICATE_POST ) . ': ' . $post_id);

            }
        }
    }

// Add the duplicate link to action list
    if ( ! function_exists( 'scm_duplicate_post_link' ) ) {
        function scm_duplicate_post_link( $actions, $post ) {
            if( current_user_can( 'manage_options' ) || current_user_can( 'publish_' . $post->post_type ) ) {
                $actions['duplicate'] = '<a href="admin.php?action=scm_duplicate_post&amp;post=' . $post->ID . '" title="' . __( 'Duplica questo oggetto', SCM_DUPLICATE_POST ) . '" rel="permalink">' . __( 'Duplica', SCM_DUPLICATE_POST ) . '</a>';
            }
            return $actions;
        }
    }

 
