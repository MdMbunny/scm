# scm-duplicate-post
Duplicate Post and Pages Integration
