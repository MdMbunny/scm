# Font Awesome #
This is a custom version of the Font Awesome repo pared down to only include:
* package.json
* /css
* /fonts

It is intended to be as small as possible while still including all of the necessary components to embed Font Awesome in a project.